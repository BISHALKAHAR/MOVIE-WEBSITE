from django.contrib import admin
from .models import Movies

# Register your models here.
admin.site.register(Movies)
