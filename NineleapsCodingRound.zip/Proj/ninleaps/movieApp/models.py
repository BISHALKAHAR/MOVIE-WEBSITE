from django.db import models
from django.shortcuts import reverse

class Movies(models.Model):
    ID = models.IntegerField(primary_key=True, default=0)
    Title = models.CharField(max_length = 200, blank=False, null=False, default='Untitled')
    Rating = models.FloatField(default=0)	
    TotalVotes = models.IntegerField(default=0)	
    Genre1 = models.CharField(max_length=200, blank=True, default='null')
    Genre2 = models.CharField(max_length=200, blank=True, default='null')
    Genre3 = models.CharField(max_length=200, blank=True, default='null')
    MetaCritic = models.IntegerField(default=0)
    Budget = models.CharField(max_length=200, blank=False, default='$0')
    Runtime = models.CharField(max_length=200, blank=False, default='0 min')

    def __str__(self):
        return str(self.Title)

    def __unicode__(self):
        return str(self.Title)

    def checkGenre(self,genreList):
        if 'all' in genreList:
            return True
        if (self.Genre1).lower() in genreList:
            return True
        if (self.Genre2).lower() in genreList:
            return True
        if (self.Genre3).lower() in genreList:
            return True
        return False

    def checkRating(self, rating):
        return float(self.Rating) >= float(rating)
        
    def checkRatingRange(self, rating1, rating2):
        return float(self.Rating) >= float(rating1) and float(self.Rating) < rating2

    def checkRuntime(self, Runtime):
        return int(self.Runtime.split(' ')[0]) <= int(Runtime)

    def get_absolute_url(self):
        return reverse('movieApp:movieDetail', args=[str(self.ID)])

    class Meta:
        db_table = 'moviedata'
