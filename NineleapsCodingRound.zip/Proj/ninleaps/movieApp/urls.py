from django.urls import path, include
from movieApp.views import MoviesDetailView, movieList, home,movieGraph

app_name = 'movieApp'

urlpatterns = [
    path('detailview/<int:pk>', MoviesDetailView.as_view(), name='movieDetail'),
    path('movieList/<int:group>', movieList, name='movieList'),
    path('home', home, name='home'),
    path('movieGraph',movieGraph, name='movieGraph'),
]
