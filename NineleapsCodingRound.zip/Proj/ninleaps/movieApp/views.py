from django.shortcuts import render
from django.http import HttpResponse
from .models import Movies
from django.views import generic


class MoviesDetailView(generic.DetailView):
    model = Movies

def home(request):
    best_movies = Movies.objects.order_by('-Rating')[0:10]
    worst_movies = Movies.objects.order_by('Rating')[0:10]
    average_movies = Movies.objects.order_by('Rating')[40:60:2]
    return render(request, 'movieApp/home.html', {'best':best_movies, 'worst':worst_movies, 'average':average_movies})

def movieList(request, group):
    if 'genre' in request.POST:
        if request.POST['genre'] != '':
            request.session['genre'] = request.POST['genre']
        else:
            request.session['genre'] = 'all'
        request.session.modified = True

    if 'rating' in request.POST: 
        if request.POST['rating'] != '':
            request.session['rating'] = request.POST['rating']
        else:
            request.session['rating'] = 0
        request.session.modified = True

    if 'runtime' in request.POST:
        if request.POST['runtime'] != '':
            request.session['runtime'] = request.POST['runtime']
        else:
            request.session['runtime'] = 240
        request.session.modified = True


    if 'genre' not in request.session:
        request.session['genre'] = 'all'
        request.session.modified = True

    if 'rating' not in request.session:
        request.session['rating'] = 0
        request.session.modified = True

    if 'runtime' not in request.session:
        request.session['runtime'] = 240
        request.session.modified = True

    genre = request.session['genre'].lower()
    
    movies = []
    for x in Movies.objects.all():
        if x.checkGenre(genre) and x.checkRating(request.session['rating']) and x.checkRuntime(request.session['runtime']):
            movies.append(x)
    curr_genre = request.session['genre']
    curr_rating = request.session['rating']
    curr_runtime = request.session['runtime']

    if group == 1:
        movies_by_rating = {}
        for x in movies:
            if x.Rating not in movies_by_rating:
                movies_by_rating[x.Rating] = [x]
            else:
                movies_by_rating[x.Rating].append(x)
        movies_grouped = []
        for x in movies_by_rating:
            movies_grouped.append([x, movies_by_rating[x]])
        movies_grouped.sort()
        return render(request, 'movieApp/movie_list_grouped.html', {'movies_grouped': movies_grouped, 'type': 'rating', 'genre': curr_genre, 'rating': curr_rating, 'runtime': curr_runtime})

    if group == 2:
        movies_by_genre = {}
        for x in movies:
            if x.Genre1 not in movies_by_genre:
                movies_by_genre[x.Genre1] = [x]
            else:
                movies_by_genre[x.Genre1].append(x)

            if x.Genre2 not in movies_by_genre:
                movies_by_genre[x.Genre2] = [x]
            else:
                movies_by_genre[x.Genre2].append(x)

            if x.Genre3 not in movies_by_genre:
                movies_by_genre[x.Genre3] = [x]
            else:
                movies_by_genre[x.Genre3].append(x)
        movies_grouped = []
        for x in movies_by_genre:
            movies_grouped.append([x, movies_by_genre[x]])

        movies_grouped.sort()
        return render(request, 'movieApp/movie_list_grouped.html', {'movies_grouped': movies_grouped, 'type': 'genre', 'genre': curr_genre, 'rating': curr_rating, 'runtime': curr_runtime})

    return render(request, 'movieApp/movies_list.html',{'movies_list':movies, 'genre':curr_genre, 'rating':curr_rating, 'runtime':curr_runtime})    

def movieGraph(request):
    mov=Movies.objects.order_by('Rating')
    good=0
    avg=0
    belavg=0
    movcounter=0
    rating=0
    for i in mov:
        rating+=i.Rating
        if i.Rating >= 8:
            good+=1
        if i.Rating >=7.8 and i.Rating<8 :
            avg+=1
        if i.Rating<7.8:
            belavg+=1           
        movcounter+=1
    avgrating=round(rating/movcounter,2)
    print(avgrating)
    ravgr=round(avgrating)
    print(ravgr)
    context = {
        'good' : good,
        'avg' : avg,
        'belavg' : belavg,
        'avgrating' : avgrating,
        'movcounter':movcounter,
    }         
    return render(request,'movieApp/graph.html',context)    